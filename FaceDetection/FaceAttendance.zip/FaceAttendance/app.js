const api_key = "rtOVG6BhvSowTvA2U3uGPQGu";
const secret_key = "DZK2SSjhIgo9K0WVCNKDZfkmtSeOnRUK";

//app.js
App({
  onLaunch: function () {
    this.requestToken();
  },
  // 初始化 鉴权获取token 存起来
  requestToken:function(){
    let that = this;
    wx.request({
      url: 'https://aip.baidubce.com/oauth/2.0/token',
      data: {
        grant_type: "client_credentials",
        client_id: api_key,
        client_secret: secret_key
      },
      success: function (res) {
        if(res.statusCode == 200){
          wx.setStorageSync("access_token", res.data.access_token);
          wx.setStorageSync("expires_in", res.data.expires_in);
          wx.setStorageSync("access_token_date", new Date().getTime());
          that.globalData.access_token = res.data.access_token;
        }
      }
    })
  },
  globalData: {
    userInfo: {} 
  }
})
