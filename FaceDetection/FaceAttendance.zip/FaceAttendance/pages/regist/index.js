// pages/regist/index.js
var app = getApp();

const API = require('../../public/api')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: "",
    info: '',
    toast: false,
    hideToast: false,
  },

  openToast: function () {
    this.setData({
      toast: true
    });
    setTimeout(() => {
      this.setData({
        hideToast: true
      });
      setTimeout(() => {
        this.setData({
          toast: false,
          hideToast: false,
        });
      }, 300);
    }, 3000);
  },
  /**
   * 点击拍照
   * 在此获取用户授权，获得用户信息
   */
  takePhoto: function () {
    const ctx = wx.createCameraContext()
    ctx.takePhoto({
      quality: 'low',
      success: (res) => {
        this.setData({
          imgUrl: res.tempImagePath
        })
      }
    })
  },
  /**
   * 上传
   * 请求接口百度AI接口
   */
  requestapi: function () {

    wx.getFileSystemManager().readFile({
      filePath: this.data.imgUrl,
      encoding: "base64",
      success: (res) => {

        wx.request({
          url: API.add,
          header: {
            "content-type": "application/json"
          },
          timeout: 3000,
          method: "POST",
          data: {
            image: res.data,
            image_type: "BASE64",
            group_id: 1,
            user_id: new Date().getTime(),
            user_info: JSON.stringify(app.globalData.userInfo)
          },
          success: (res) => {
            // 上传成功以后
            wx.redirectTo({
              url: '/pages/msg/success?type=regist'
            })
          },
          fail(err) {
            console.log('接口调用失败:', err)
          },
          complete() {
            console.log('请求完成')
          }
        })

      },
      err: (errMsg) => {
        console.log(errMsg)
      },
    })
  },
  // 分享按钮
  onShareAppMessage(){
    return {
      title: '考勤打卡信息注册',
      path: '/page/form/index'
    }
  }
})